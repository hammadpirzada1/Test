<?php namespace Repositories;

class User {}