<?php

class Restful_Controller extends Controller {

	public $restful = true;

	public function get_index()
	{
		return __FUNCTION__;
	}

	public function post_index()
	{
		return __FUNCTION__;
	}

}